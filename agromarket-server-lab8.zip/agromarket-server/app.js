import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { pool } from './db/pool.js';
import { logger } from './middleware/logger.js';
import { errorHandler } from './middleware/errorHandler.js';
import authRouter from './routes/auth.js';
import productsRouter from './routes/products.js';
import ordersRouter from './routes/orders.js';

const app = express();

// ВПИШИТЕ СВОЁ ФИО (используется в /api/about)
const AUTHOR = 'Каплин Никита Сергеевич';

// Конвейер middleware: helmet -> cors -> json -> logger -> маршруты -> 404 -> обработчик ошибок
app.use(helmet()); // защитные HTTP-заголовки — первым middleware
app.use(cors({ origin: process.env.CORS_ORIGIN })); // разрешаем только наш frontend
app.use(express.json({ limit: '10kb' })); // тело запроса не больше 10 КБ

// В тестах лог каждого запроса только мешает читать результат
if (process.env.NODE_ENV !== 'test') {
  app.use(logger);
}

app.get('/', (req, res) => {
  res.send('АгроМаркет API работает');
});

// «Жив ли сервер и есть ли связь с базой?»
app.get('/api/health', async (req, res) => {
  await pool.query('SELECT 1');
  res.json({ status: 'ok', db: 'connected', time: new Date().toISOString() });
});

app.get('/api/about', (req, res) => {
  res.json({ name: 'АгроМаркет', version: '1.0', author: AUTHOR });
});

app.use('/api/auth', authRouter);
app.use('/api/products', productsRouter);
app.use('/api/orders', ordersRouter);

// Сюда доходят только запросы, которые не обработал ни один маршрут
app.use((req, res) => {
  res.status(404).json({ error: `Маршрут ${req.method} ${req.originalUrl} не найден` });
});

app.use(errorHandler); // ← последний middleware

export default app; // приложение БЕЗ запуска сервера
