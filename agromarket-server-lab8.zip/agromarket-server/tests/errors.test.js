import { describe, it, expect } from 'vitest';
import request from 'supertest';
import app from '../app.js';

// Проверяем errorHandler и обработчик 404: непокрытые ветки из отчёта о покрытии
describe('Обработка ошибок', () => {
  it('неизвестный маршрут — 404 в формате JSON', async () => {
    const res = await request(app).get('/api/no-such-route');
    expect(res.status).toBe(404);
    expect(res.body).toHaveProperty('error');
  });

  it('битый JSON в теле — 400', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .set('Content-Type', 'application/json')
      .send('{"email": "a@a.kz", ');
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/JSON/);
  });

  it('слишком большое тело (> 10 КБ) — 413', async () => {
    const res = await request(app)
      .post('/api/orders')
      .send({ name: 'x'.repeat(11 * 1024), email: 'a@a.kz', quantity: 20 });
    expect(res.status).toBe(413);
  });

  it('id не числом (ошибка PostgreSQL 22P02) — 400, а не 500', async () => {
    const res = await request(app).get('/api/products/abc');
    expect(res.status).toBe(400);
  });
});

describe('Защитные заголовки helmet', () => {
  it('ответ содержит X-Content-Type-Options: nosniff', async () => {
    const res = await request(app).get('/api/health');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
  });
});
