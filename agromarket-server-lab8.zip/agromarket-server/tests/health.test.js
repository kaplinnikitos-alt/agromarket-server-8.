import { describe, it, expect } from 'vitest';
import request from 'supertest';
import app from '../app.js';

describe('GET /api/health', () => {
  it('отвечает 200', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
  });

  it('сообщает, что база подключена', async () => {
    const res = await request(app).get('/api/health');
    expect(res.body.status).toBe('ok');
    expect(res.body.db).toBe('connected');
  });
});

describe('GET /api/about', () => {
  it('возвращает название приложения и автора', async () => {
    const res = await request(app).get('/api/about');
    expect(res.status).toBe(200);
    expect(res.body.name).toBe('АгроМаркет');
    expect(res.body.author).toBeTruthy();
  });
});
