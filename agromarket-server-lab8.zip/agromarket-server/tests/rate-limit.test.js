import { describe, it, expect } from 'vitest';
import request from 'supertest';
import app from '../app.js';
import { uniqueEmail } from './helpers.js';

// Отдельный файл: счётчик попыток хранится в памяти, и другие тесты входа
// не должны его «подъедать»
describe('Ограничение попыток входа', () => {
  it('5 неудачных попыток — 401, шестая — 429 с Retry-After', async () => {
    const email = uniqueEmail('brute');
    const attempt = () =>
      request(app).post('/api/auth/login').send({ email, password: 'неверный-пароль' });

    for (let i = 0; i < 5; i++) {
      const res = await attempt();
      expect(res.status).toBe(401);
    }

    const blocked = await attempt();
    expect(blocked.status).toBe(429);
    expect(blocked.headers['retry-after']).toBeTruthy();
    expect(blocked.body.error).toMatch(/Слишком много/);
  });
});
